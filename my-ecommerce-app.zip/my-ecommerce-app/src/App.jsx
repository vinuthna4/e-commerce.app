import React, { useState } from 'react';
import ProductCard from './components/ProductCard';
import Cart from './components/Cart';

const products = [
  {
    id: 1,
    name: 'Classic T-Shirt',
    price: 299,
    image: 'https://cdnc.lystit.com/photos/2013/10/19/ralph-lauren-active-royal-classicfit-crew-neck-shortsleeve-cotton-jersey-pocket-tshirt-product-1-14264369-322912462.jpeg'
  },
  {
    id: 2,
    name: 'Denim Jeans',
    price: 799,
    image: 'https://fabrilife.com/products/642ad72b61ff6-square.jpg'
  },
  {
    id: 3,
    name: 'Stylish Shoes',
    price: 1499,
    image: 'https://ae01.alicdn.com/kf/HTB1uiy7KVXXXXXgXXXXq6xXFXXXG/2015-comfortable-running-shoes-super-light-sneakers-wearable-men-athletic-shoes-brand-sport-shoes-running-men.jpg'
  },
  {
    id: 4,
    name: 'Leather Wallet',
    price: 499,
    image: 'https://i.etsystatic.com/15615725/r/il/a1f930/2289085880/il_fullxfull.2289085880_aqlo.jpg'
  },
  {
    id: 5,
    name: 'Analog Watch',
    price: 1299,
    image: 'https://c8.alamy.com/comp/S3F5XM/casio-waveceptor-lineage-classic-anadigi-digital-analog-solar-atomic-titanium-wrist-watch-on-a-black-background-S3F5XM.jpg'
  },
  {
    id: 6,
    name: 'Backpack',
    price: 999,
    image: 'https://i5.walmartimages.com/asr/16286794-a68a-441c-bad7-5dce3e71e119.9f3cf0a2d67213261293986ba316b610.jpeg'
  }
];

function App() {
  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  return (
    <div className="container">
      <h1>🛍️ My eCommerce Store</h1>
      <div className="product-list">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} addToCart={addToCart} />
        ))}
      </div>
      <Cart cartItems={cart} />
    </div>
  );
}

export default App;
