import React, { useState } from 'react';

const Cart = ({ cartItems }) => {
  const [orderPlaced, setOrderPlaced] = useState(false);
  const total = cartItems.reduce((sum, item) => sum + item.price, 0);

  const placeOrder = () => {
    if (cartItems.length === 0) return;
    setOrderPlaced(true);
  };

  return (
    <div className="cart">
      <h2>🛒 Cart</h2>

      {orderPlaced ? (
        <div>
          <h3>✅ Order placed successfully!</h3>
          <p>Thank you for shopping with us.</p>
        </div>
      ) : cartItems.length === 0 ? (
        <p>No items in cart.</p>
      ) : (
        <>
          <ul className="cart-list">
            {cartItems.map((item, index) => (
              <li key={index} className="cart-item">
                <img src={item.image} alt={item.name} />
                <div>
                  <strong>{item.name}</strong>
                  <p>₹{item.price}</p>
                </div>
              </li>
            ))}
          </ul>
          <h3>Total: ₹{total}</h3>
          <button onClick={placeOrder} className="place-order-button">
            Place Order
          </button>
        </>
      )}
    </div>
  );
};

export default Cart;
